 /**
  * 表情库
  * @type {Object}
  */
 var weixinMoji = {
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',
     '[害羞]': 'haixiu',


 };

 /**
  * 字转表情入口函数
  * @param  {[type]} text [description]
  * @return {[type]}      [description]
  */
 function weixinMojiTranslate(text) {
         var textAfter = text.replace(/\[.{1,3}\]/g, function(moji) {
             return weixinMojiImg(moji);
         });
         return textAfter;
     }
     /**
      * 微信中文编码转图片html
      * @param  {[type]} text [中文编码]
      * @return {[type]}      图片html
      *
      */
 function weixinMojiImg(text) {
     return '<img width="14" src="img/' + weixinMoji[text] + '.png">';
 }